# SALTWAKE — Encounter Bridge (proposed v0.29.3 development checkpoint)

This is a standalone extension of the uploaded v0.29.2 Unseen War prototype. It is not the full SALTWAKE game, a replacement HTML build, or a verified Nightwatch integration. The phase name/version is a proposed engineering checkpoint, not an established roadmap release. Existing art, map geometry, quests, inventory, combat and saves have not been edited. No placeholder art was added.

## Changes
- `unseen-war.mjs`: original prototype with a site-lock check in spawn, movement and strategic updates. Locked sites cannot be updated by off-screen combat or receive new strategic arrivals.
- `encounter-bridge.mjs`: owns the strategic/live handoff, issues unique encounter tokens, returns detached spawn manifests, and reconciles casualties, remaining monsters, retreat flags and salvage quantities. Rejects duplicate or stale commits and invalid outcomes before mutating strategic state.
- `test.mjs`: nine original tests, unchanged.
- `bridge.test.mjs`: thirteen additional tests.
- `QA.txt`: real output from `node --test test.mjs bridge.test.mjs` (22 passing).

## Host integration sketch
```js
import { EncounterBridge } from './encounter-bridge.mjs';
const bridge = new EncounterBridge({sites, factions, seed:12345});
// Host's low-frequency strategic update:
const events = bridge.tick(); // internal; do not expose all distant events to player
// When a site becomes visible and its live actors need creating:
const encounter = bridge.enter(siteId);
// Host spawns actual actors with established assets, IDs, positions and AI.
// Host controls all local combat, loot and actor interactions until handoff.
// Reconcile exactly once on unload/checkpoint:
const result = bridge.commit(siteId, encounter.token, {
  threat: remainingMonsterCount,
  salvage: remainingLocalSalvageUnits,
  playerTaken: unitsRecoveredFromThisEncounter,
  patrols: encounter.patrols.map(p => ({
    id:p.id, members:survivorCountFor(p.id),
    cargo:remainingCargoFor(p.id), retreat:shouldRetreat(p.id)
  }))
});
// After ALL live sites are reconciled, persist bridge.snapshot() atomically
// with the host game save. Restore via bridge.restore(savedBridgeState).
```

These are proposed integration hooks, not actual Nightwatch function names. Keep the bridge as the sole strategic authority. The host adapter must make loot changes and commit atomic with its inventory/actor state; do not grant loot twice from the receipt. `abortBeforePlay` is only for failed initialization before any live-world changes. The adapter must not abort an already-played encounter. The bridge does not issue item IDs or implement actual per-item accounting, inventory transactions, AI pathfinding, actor creation, live attacks, rendering, world coordinates, or browser save migration. The aggregate quantities are deliberately limited to encounter salvage. No new canon factions or locations are asserted. The original provisional cap of two patrol groups is retained, not a validated cap on individual humans; final rarity tuning must be done against the actual game. Brineworn aggression is preserved as a requirement, not implemented in live actor AI here.

## Remaining release gates
1. Retrieve the actual Nightwatch v0.29.1 development ZIP. Inspect the code, data, graphics and existing tests.
2. Bind real world site IDs/coordinates and actual actor IDs. Preserve quest locations, exits, collision geometry and image assets. Use existing faction and Brineworn AI; maintain rarity of humans. Add no unsupported canon.
3. Implement the live adapter and atomic item/inventory reconciliation. Decide how to handle autosave during live combat (checkpoint/reopen or persist a complete live state); do not remove the current game's autosave behavior. Add item identity, actor lifetime and migration tests.
4. Verify nearby cues and off-screen event visibility; avoid omniscient player knowledge. Validate actual combat, retreats, extraction, inventory, quests, crafting, region transitions, persistence and performance in a browser.
5. Export the full playable HTML and reproducible development ZIP only after integration and regression testing. This checkpoint is not a playable release.

The next productive step requires the full Nightwatch source rather than another independent subsystem.
