from pathlib import Path
p=Path(__file__).resolve().parent
parts=[]
for filename,cls in [('unseen-war.mjs','UnseenWar'),('encounter-bridge.mjs','EncounterBridge'),('live-host.mjs','LiveHost')]:
    body='\n'.join(line for line in (p/filename).read_text().splitlines() if not line.startswith('import ')).replace('export class ','class ')
    parts.append(f'const {cls}=(()=>{{\n{body}\nreturn {cls};}})();')
(p/'diagnostic.html').write_text((p/'harness-template.html').read_text().replace('/* BUNDLE */','\n'.join(parts)))
