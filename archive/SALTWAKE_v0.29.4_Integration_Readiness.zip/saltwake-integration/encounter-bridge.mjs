import {UnseenWar} from './unseen-war.mjs';
const clone=structuredClone;
const validInt=n=>Number.isSafeInteger(n)&&n>=0;
const requireThat=(ok,msg)=>{if(!ok)throw new Error(msg);};
// Host owns actors while a site is live; simulation owns all other sites.
// No dependency on unverified Nightwatch APIs. Site IDs are host-provided.
export class EncounterBridge {
  constructor(config){this.war=new UnseenWar(config);this.active=new Map();this.sequence=0;this.playerRecovered=0;}
  tick(){const events=this.war.tick();this.war.drainEvents();return events;}
  enter(siteId){
    const s=this.war.site(siteId);requireThat(s&&!s.safe,'Unknown or protected encounter site');
    requireThat(!this.active.has(siteId),'Site already live');
    const session={token:++this.sequence,siteId,threat:s.threat,salvage:s.salvage,monsterKind:s.monsterKind??'wildlife',patrols:clone(this.war.patrols.filter(p=>p.site===siteId))};
    this.war.lockedSites.add(siteId);this.active.set(siteId,session);return clone(session);
  }
  // All cargo and local salvage must be reconciled; no silent duplication or loss.
  // The adapter must map units to the actual item identities in the game.
  commit(siteId,token,result){
    const session=this.active.get(siteId);requireThat(session&&session.token===token,'Stale or missing encounter token');
    requireThat(result&&validInt(result.threat)&&result.threat<=session.threat,'Invalid remaining threat');
    requireThat(validInt(result.salvage)&&validInt(result.playerTaken),'Invalid salvage quantities');
    requireThat(Array.isArray(result.patrols)&&result.patrols.length===session.patrols.length,'Missing or extra patrol reports');
    const prior=new Map(session.patrols.map(p=>[p.id,p]));const seen=new Set();const updates=[];
    let total=result.salvage+result.playerTaken;
    for(const row of result.patrols){
      const old=prior.get(row.id);requireThat(old&&!seen.has(row.id),'Unknown or duplicate patrol');seen.add(row.id);
      requireThat(validInt(row.members)&&row.members<=old.members&&validInt(row.cargo),'Invalid survivors or cargo');
      requireThat(row.members>0||row.cargo===0,'Dead patrol must drop cargo');
      requireThat(typeof row.retreat==='boolean','Missing retreat flag');
      total+=row.cargo;updates.push({...old,members:row.members,cargo:row.cargo,state:row.retreat||row.members===1?'retreat':old.state});
    }
    const initial=session.salvage+session.patrols.reduce((n,p)=>n+p.cargo,0);
    requireThat(Number.isSafeInteger(total)&&total===initial,'Salvage conservation violation');
    requireThat(Number.isSafeInteger(this.playerRecovered+result.playerTaken),'Recovery counter overflow');
    const site=this.war.site(siteId);site.threat=result.threat;site.salvage=result.salvage;
    this.war.patrols=this.war.patrols.filter(p=>p.site!==siteId).concat(updates.filter(p=>p.members>0));
    this.playerRecovered+=result.playerTaken;this.active.delete(siteId);this.war.lockedSites.delete(siteId);
    return {siteId,token,playerTaken:result.playerTaken,survivors:updates.reduce((n,p)=>n+p.members,0)};
  }
  // Abort only when no live effects were applied (e.g. failed actor creation).
  abortBeforePlay(siteId,token){const s=this.active.get(siteId);requireThat(s&&s.token===token,'Stale or missing encounter token');this.active.delete(siteId);this.war.lockedSites.delete(siteId);}
  snapshot(){requireThat(!this.active.size,'Commit all live encounters before saving');return clone({schema:1,sequence:this.sequence,playerRecovered:this.playerRecovered,war:this.war.snapshot()});}
  restore(snapshot){requireThat(!this.active.size,'Cannot restore over a live encounter');requireThat(snapshot?.schema===1&&validInt(snapshot.sequence)&&validInt(snapshot.playerRecovered),'Invalid bridge snapshot');requireThat(snapshot.war&&Array.isArray(snapshot.war.sites)&&Array.isArray(snapshot.war.patrols),'Invalid world snapshot');this.war.restore(snapshot.war);this.war.lockedSites.clear();this.sequence=Math.max(this.sequence,snapshot.sequence);this.playerRecovered=snapshot.playerRecovered;return this;}
}
