# SALTWAKE — v0.29.4 integration readiness checkpoint

This is NOT the original game, its full integration, or a playable alpha release. Nightwatch v0.29.1 source was not accessible in the session. This package extends the existing standalone v0.29.3 module; it does not modify canonical maps, art, or quests. Test site IDs and factions are synthetic fixtures. No independent agents were available; the work is divided into the following disciplines for future integration.

## Delivered
- Existing strategic simulation and encounter bridge, plus `live-host.mjs` reference host.
- Encounter-scoped actor and salvage IDs, one-time pickup, death/cargo drop, commit-on-exit, full active encounter checkpoint and validation of live identity conservation. IDs do not persist across different encounter activations; actual world item IDs must be mapped in the real host. The reference inventory stores aggregate salvage IDs only; real inventory transaction, equipment, stacking and extraction behavior remain unimplemented. Checkpoints are in memory in the diagnostic (not persistent across page reload).
- 30 passing Node tests (`node --test test.mjs bridge.test.mjs host.test.mjs`). See QA.txt.
- Self-contained `diagnostic.html`: open in a browser to exercise the simulated world, live outcome actions, save and restore. Chromium smoke test using in-memory HTML injection passed; direct file URL navigation in the testing environment was blocked. This UI is a developer diagnostic, not the in-game UI or real-time combat.
- `harness-template.html` is the unbundled source template; `build.py` generates the self-contained diagnostic.

## Release workstreams (not independently deployed agents)
| Discipline | Integration tasks | Acceptance gate |
|---|---|---|
| Systems | Inspect actual game runtime; bind canonical sites, actor IDs, faction data, quest states, item definitions; connect world tick, encounter activation and unload; preserve saves and migrate older schema. | No duplicate actors/loot, no quest resets, no conflicting simulation control. |
| Gameplay | Actual navigation/collision, local AI, hostility, retreat, damage, player intervention and extraction; tune rare human encounters; fully mutated Brineworn hostile to humans. | Player can observe, intervene, disengage, extract; no enemy spawn inside safe settlements or blocked geometry. |
| Art | Audit existing sheets, texture sizes and anchors; generate actual image sprites consistent with approved top-down HD pixel art; directional motion and hit/death animations; consistent shadows. | No procedural placeholder art in release; preserve map coordinates and exits. No new image assets generated in this checkpoint. |
| UI | Audit current HUD, quest journal, inventory and controls; preserve health/stamina maximums and state when consuming food; improve visual hierarchy and input feedback. | HUD remains stable, no clipping or lost keyboard/gamepad/mouse controls that were previously supported. |
| Performance | Profile current browser build, culling and pathfinding workload, asset decoding; tune frame pacing without changing gameplay. | Compare baseline and updated frame timing on identical hardware; no claim of FPS improvement until measured. |
| QA | Run all old tests and added tests; browser playthrough with actual world, quests, crafting, extraction, saves, death, encounter unload/re-entry, and art review. | No critical regressions; verified game export plus reproducible source ZIP. |

## Required next input
Upload `SALTWAKE_v0.29.1_Nightwatch_Development.zip` (approximately 60.9 MB); the current small encounter ZIPs contain no original game. The standalone Nightwatch HTML is a fallback if the development ZIP is unavailable. Without one of these, the actual game cannot be updated. Keep the last known-good release intact; create a separate integration branch/package, then export a playable test only after the real build passes the release gates. No new canon names, map coordinates or factions have been established by this checkpoint.
