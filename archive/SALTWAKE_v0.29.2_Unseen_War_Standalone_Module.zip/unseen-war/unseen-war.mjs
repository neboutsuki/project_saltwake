// SALTWAKE v0.29.2 candidate: standalone strategic encounter simulation.
// No dependencies, rendering, world coordinates, or player-driven triggers.
export class UnseenWar {
  constructor({sites, factions, seed=1, maxPatrols=2, spawnChance=.12, emit=()=>{}}) {
    if (!Array.isArray(sites)||!Array.isArray(factions)||!sites.length||!factions.length) throw Error('Sites and factions required');
    this.sites=structuredClone(sites); this.factions=structuredClone(factions); this.seed=seed>>>0; this.maxPatrols=Math.max(0,Math.floor(maxPatrols)); this.spawnChance=spawnChance; this.emit=emit; this.patrols=[]; this.tickCount=0; this.nextId=1; this.events=[];
    if(new Set(this.sites.map(s=>s.id)).size!==this.sites.length) throw Error('Duplicate site ID');
    for(const s of this.sites){s.salvage=Math.max(0,Math.floor(s.salvage??0));s.threat=Math.max(0,Math.floor(s.threat??0)); s.neighbors??=[];}
  }
  random(){this.seed=(Math.imul(1664525,this.seed)+1013904223)>>>0;return this.seed/4294967296;}
  pick(xs){return xs[Math.floor(this.random()*xs.length)];}
  site(id){return this.sites.find(s=>s.id===id);}
  log(type,p,s,extra={}){const e={tick:this.tickCount,type,patrol:p.id,faction:p.faction,site:s.id,...extra};this.events.push(e);this.emit(structuredClone(e));return e;}
  spawn(){if(this.patrols.length>=this.maxPatrols)return null;const candidates=this.sites.filter(s=>!s.safe&&!this.patrols.some(p=>p.site===s.id));if(!candidates.length)return null;const s=this.pick(candidates),f=this.pick(this.factions); const p={id:'patrol-'+this.nextId++,faction:f.id,hostile:!!f.hostile,site:s.id,members:2+Math.floor(this.random()*2),state:'patrol',cargo:0,age:0};this.patrols.push(p);this.log('patrol_arrived',p,s,{members:p.members});return p;}
  move(p,s,retreat=false){const candidates=s.neighbors.map(id=>this.site(id)).filter(n=>n&&!n.safe);if(!candidates.length)return false;const n=retreat?[...candidates].sort((a,b)=>a.threat-b.threat||String(a.id).localeCompare(String(b.id)))[0]:this.pick(candidates);p.site=n.id;this.log(retreat?'retreat_moved':'patrol_moved',p,n,{from:s.id});return true;}
  remove(p,s,type){this.log(type,p,s,{survivors:p.members,cargo:p.cargo});this.patrols=this.patrols.filter(x=>x!==p);}
  tick(){this.tickCount++;const start=this.events.length;const active=[...this.patrols];if(this.random()<this.spawnChance)this.spawn();for(const p of active){if(!this.patrols.includes(p))continue;const s=this.site(p.site);p.age++;
      if(p.state==='retreat'){this.move(p,s,true);this.remove(p,this.site(p.site),'survivors_departed');continue;}
      if(p.age>=20){this.remove(p,s,'patrol_departed');continue;}
      if(s.threat>0){p.state='hunt';this.log('monster_engaged',p,s,{threat:s.threat,kind:s.monsterKind??'wildlife'});const initial=s.threat;const kills=Math.min(initial,1+Math.floor(this.random()*p.members));s.threat-=kills;const casualties=this.random()<Math.min(.8,initial/(p.members*4))?1:0;p.members-=casualties;this.log('battle_resolved',p,s,{monstersDefeated:kills,casualties,survivors:p.members,remainingThreat:s.threat});if(p.members===0){s.salvage+=p.cargo;this.remove(p,s,'patrol_lost');continue;}if(p.members===1||s.threat>=p.members*2){p.state='retreat';this.log('retreat_started',p,s,{survivors:p.members});}continue;}
      const rivals=this.patrols.filter(q=>q!==p&&q.site===s.id&&q.faction!==p.faction&&q.hostile&&p.hostile&&q.state!=='retreat');
      if(rivals.length&&s.salvage>0){const q=rivals[0];p.state='ambush';this.log('salvage_contested',p,s,{rival:q.id});const loser=this.random()<.5?p:q;loser.members=Math.max(0,loser.members-1);if(!loser.members){s.salvage+=loser.cargo;this.remove(loser,s,'patrol_lost');}else{loser.state='retreat';this.log('retreat_started',loser,s,{survivors:loser.members});}continue;}
      if(s.salvage>0){p.state='salvage';const amount=Math.min(s.salvage,p.members);s.salvage-=amount;p.cargo+=amount;this.log('salvage_taken',p,s,{amount,remaining:s.salvage});continue;}
      p.state=p.hostile&&s.ambush?'ambush':'patrol';if(p.state==='ambush'){this.log('ambush_waiting',p,s);if(p.age%3!==0)continue;}this.move(p,s);
    }return this.events.slice(start);}
  drainEvents(){const e=this.events;this.events=[];return e;}
  snapshot(){return structuredClone({sites:this.sites,patrols:this.patrols,seed:this.seed,tickCount:this.tickCount,nextId:this.nextId,maxPatrols:this.maxPatrols,spawnChance:this.spawnChance});}
  restore(snapshot){for(const k of ['sites','patrols','seed','tickCount','nextId','maxPatrols','spawnChance'])this[k]=structuredClone(snapshot[k]);this.events=[];return this;}
}
