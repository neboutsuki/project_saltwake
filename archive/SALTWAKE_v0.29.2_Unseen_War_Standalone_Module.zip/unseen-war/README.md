# SALTWAKE v0.29.2 — The Unseen War
## Standalone candidate module, NOT a playable release or merged patch
Nightwatch v0.29.1 could not be materialized from the Library. This module is a working strategic encounter prototype, deliberately independent of unverified game APIs. It does not replace Nightwatch or modify its assets, maps, saves, UI, combat, or quests.

### Contents
- `unseen-war.mjs`: deterministic site-level patrol and encounter simulation.
- `test.mjs`: nine Node.js tests (`node --test test.mjs`).
- `QA.txt`: actual standalone test output.

### Implemented
Configurable rare-human cap (default two patrols), probabilistic spawning, safe settlement exclusion, patrol relocation between connected sites, site-specific ambush waiting, hunting monsters including Brineworn, abstract combat casualties, competing hostile factions at salvage sites, cargo, retreat and departing survivor events, seeded randomness and serializable simulation state. No player input is necessary to advance time. Faction IDs and sites are supplied by the host; the included test IDs are fixtures and not additions to canon.

### Integration contract (proposed, not verified against Nightwatch)
```js
import { UnseenWar } from './unseen-war.mjs';
const war = new UnseenWar({
  sites: validatedWorldSites, // [{id, neighbors:[id], safe, salvage, threat, monsterKind, ambush}]
  factions: existingFactionDefinitions, // [{id, hostile}]
  seed: 12345,
  maxPatrols: 2,
  spawnChance: 0.12,
});
// On the host's strategic world tick, not per animation frame:
const events = war.tick();
war.drainEvents(); // clear retained event history after consumption
// Persist war.snapshot() alongside existing world state; restore via war.restore(snapshot).
```

The host must reconcile this simulation with its authoritative actors and inventory. Do not run abstract combat resolution on top of live combat for the same encounter: visible encounters should delegate to the existing combat system, then synchronize survivors and resources back to strategic state. Do not spawn abstract quantities as duplicate loot. Real patrol movement, ambush detection, attacks, pathfinding, hostility relationships, actual monster/Brineworn AI, animation and player-facing feedback are integration tasks, not implemented here. Default cap and spawn probability are provisional balance choices, not approved final tuning. Use a low-frequency strategic clock; do not run the tick every frame. Test fixtures only use three abstract sites. The binary/asset layer is intentionally unchanged; no generated placeholder graphics are included.

### Integration and release gates
1. Open actual v0.29.1 development ZIP; inspect world state, existing AI, save/load, entity lifecycle, map IDs and terrain collision. Establish one owner for combat and salvage state.
2. Bind eligible encounter sites to existing coordinates and paths; forbid spawns in the hub and inaccessible tiles. Preserve existing exits and buildings.
3. Bridge the patrol lifecycle into existing actors, faction hostility, actual generated sprites and animation. Brineworn remain aggressive to humans; no friendly dialogue or restored humanity. Avoid adding new canon factions without a lore check.
4. Materialize nearby encounters only once, preserve encounter state across region transitions and saves, and make retreat paths navigable. Allow off-screen encounters without player proximity.
5. Add grounded encounter clues, rare ambush behavior and post-battle survivors using existing UI and assets. Verify salvage ownership and inventory conservation.
6. Run full Nightwatch regression (quests, transitions, inventory, crafting, extraction, combat, save migration, runtime errors), actual browser playtests, performance profiling and new AI integration tests. Package a playable HTML and development ZIP only after integration is verified.
